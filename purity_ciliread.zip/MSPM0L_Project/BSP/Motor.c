#include "board.h"
#include "ti_msp_dl_config.h"
#include "Motor.h"


/***********************ARR��1000************************/

void LG(uint16_t speed)//����
{
	DL_GPIO_setPins(M_PORT,M_Motor_A_PIN);
	DL_GPIO_clearPins(M_PORT,M_Motor_B_PIN);
	
	DL_TimerG_setCaptureCompareValue(MOTOR_INST,speed,GPIO_MOTOR_C0_IDX);		

}


void LB(uint16_t speed)//����
{
	
	DL_GPIO_clearPins(M_PORT,M_Motor_A_PIN);
	DL_GPIO_setPins(M_PORT,M_Motor_B_PIN);
	
	DL_TimerG_setCaptureCompareValue(MOTOR_INST,speed,GPIO_MOTOR_C0_IDX);		
}

void LS(void)
{
	DL_GPIO_clearPins(M_PORT,M_Motor_B_PIN);
	DL_GPIO_clearPins(M_PORT,M_Motor_A_PIN);
	DL_TimerG_setCaptureCompareValue(MOTOR_INST,0,GPIO_MOTOR_C0_IDX);		
}

void RG(uint16_t speed)//����
{
	
	DL_GPIO_setPins(M_PORT,M_Motor_A_2_PIN);
	DL_GPIO_clearPins(M_PORT,M_Motor_B_2_PIN);
	
	DL_TimerG_setCaptureCompareValue(MOTOR_INST,speed,GPIO_MOTOR_C1_IDX);		
}


void RB(uint16_t speed)//����
{
	
	DL_GPIO_clearPins(M_PORT,M_Motor_A_2_PIN);
	DL_GPIO_setPins(M_PORT,M_Motor_B_2_PIN);
	
	DL_TimerG_setCaptureCompareValue(MOTOR_INST,speed,GPIO_MOTOR_C1_IDX);		
}

void RS(void)
{
	DL_GPIO_clearPins(M_PORT,M_Motor_B_2_PIN);
	DL_GPIO_clearPins(M_PORT,M_Motor_A_2_PIN);
	DL_TimerG_setCaptureCompareValue(MOTOR_INST,0,GPIO_MOTOR_C1_IDX);		
}

void Allgo(int16_t speed)
{
	DL_GPIO_setPins(M_PORT,M_Motor_A_PIN);
	DL_GPIO_clearPins(M_PORT,M_Motor_B_PIN);
	
	DL_TimerG_setCaptureCompareValue(MOTOR_INST,speed,GPIO_MOTOR_C0_IDX);		

	DL_GPIO_setPins(M_PORT,M_Motor_A_2_PIN);
	DL_GPIO_clearPins(M_PORT,M_Motor_B_2_PIN);
	
	DL_TimerG_setCaptureCompareValue(MOTOR_INST,speed,GPIO_MOTOR_C1_IDX);		
}

void Allstop(void)
{
	DL_GPIO_clearPins(M_PORT,M_Motor_B_2_PIN);
	DL_GPIO_clearPins(M_PORT,M_Motor_A_2_PIN);
	DL_GPIO_clearPins(M_PORT,M_Motor_B_PIN);
	DL_GPIO_clearPins(M_PORT,M_Motor_A_PIN);
	DL_TimerG_setCaptureCompareValue(MOTOR_INST,0,GPIO_MOTOR_C0_IDX);		
	DL_TimerG_setCaptureCompareValue(MOTOR_INST,0,GPIO_MOTOR_C1_IDX);		
}