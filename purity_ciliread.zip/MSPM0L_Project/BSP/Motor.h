#include "board.h"

#ifndef MOTOR_H_
#define MOTOR_H_


//
//
void LG(uint16_t speed);
void LB(uint16_t speed);
void RG(uint16_t speed);
void RB(uint16_t speed);


void LS(void);
void RS(void);

void Allgo(int16_t speed);
void Allstop(void);

#endif


