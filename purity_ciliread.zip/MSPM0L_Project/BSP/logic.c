//#include "PID.h"
#include "board.h"
#include "ti_msp_dl_config.h"
#include "logic.h"
#include "Motor.h"
#include "drv_oled.h"
/*******�Ҷȴ���������*******/
uint8_t data_arr[8] = {0};
volatile uint8_t track=0;
int8_t trackstate=0;
float VELKp=-5,VELKi=-1,VELKd=-3;
extern float PWM_zhuanxiang;
extern float pitch,roll,yaw;   //ŷ����

void tackle_dat(void)
{		
		display_6_8_number_f1(80,4,data_arr[0]);
		display_6_8_number_f1(70,4,data_arr[1]);
		display_6_8_number_f1(60,4,data_arr[2]);
		display_6_8_number_f1(50,4,data_arr[3]);
		display_6_8_number_f1(40,4,data_arr[4]);
		display_6_8_number_f1(30,4,data_arr[5]);
		display_6_8_number_f1(20,4,data_arr[6]);
		display_6_8_number_f1(10,4,data_arr[7]);
	//0~3���  4~7�ұ�
}
  uint8_t Gray_read()
{
		 uint8_t Graybit=0;
		 uint8_t back = 0;
	for (int i = 0; i < 8; ++i)
	{	
		
		DL_GPIO_clearPins(GPIO_PORT,GPIO_CLK_PIN);//ʱ�ӵ͵�ƽ
		if(DL_GPIO_readPins(GPIO_PORT,GPIO_DAT_PIN)!=0)
		{Graybit=1;}
		else{Graybit=0;}
		data_arr[i]=Graybit;
		
		
		DL_GPIO_setPins(GPIO_PORT,GPIO_CLK_PIN);  //ʱ�Ӹߵ�ƽ
		//delay_ms(8);
		delay_us(5);
	}
	return back;
}
void track_line(void)
{	
	uint8_t Lflag;  uint8_t Rflag;
	uint8_t i=0;
	Gray_read();
	
	
		while(i<3){Lflag+=data_arr[i];i++;}
		while(i++<7){Rflag+=data_arr[i];i++;}

}

//����ʽ�ٶȻ���
int16_t VEL_PID(int16_t vel,int16_t vel_ex)	//vel��õ�ǰ��ʵ���ٶ�--vel_ex����Ŀ���ٶ�
{
		
  	static err velerr;
		static int flag=0;
		if(flag<5)	
			{
				if(flag==0)
				{velerr.curr_last_diff=0;}
			
			velerr.curr_last_diff+=velerr.curr;
				
				if(flag==4)
				flag=0;
			}
	
	float a=0.3; 	//�˲�ϵ������ӳ�˲��̶ȣ�
	int output;	
	velerr.curr=vel-vel_ex;//�ٶ�ƫ��	                                           velocity = velocity_measure - velocity_calcu;          //
	velerr.curr=a*velerr.curr + (1-a)*velerr.last;//һ���ٶ��˲�           filt_velocity = a*velocity + (1-a)*last_filt_velocity; //	
	velerr.curr_diff=velerr.curr-velerr.last;//һ�׵���     �ٶ�ƫ��Ĳ�ֵ   velocity_err = filt_velocity - last_filt_velocity;		//
	
	//velerr.curr_last_diff=velerr.curr_diff-velerr.last_diff;//���׵�     velocity_err_err = velocity_err - last_velocity_err;
	
	
	  /*****************���ݽ��湤��***********************/
	velerr.last=velerr.curr;//last_filt_velocity = filt_velocity;                    //�˴��ٶ�ƫ���¼Ϊ���ϴ��ٶ�ƫ�
	velerr.last_diff=velerr.curr_diff;//last_velocity_err = velocity_err;
	/************************************************************/
	output=VELKp*velerr.curr_diff+VELKi*velerr.curr+VELKd*velerr.curr_last_diff;//VELKp*velocity_err + VELKi*filt_velocity + VELKd*velocity_err_err
	return output;
}


/*		track=Gray_read();
		data_arr[0] = (uint8_t)( track & 0x01); // ��͵�λר��
		data_arr[1] = (uint8_t)( track & 0x02) >> 1;
		data_arr[2] = (uint8_t)( track & 0x04) >> 2;
		data_arr[3] = (uint8_t)( track & 0x08) >> 3;
		data_arr[4] = (uint8_t)( track & 0x10) >> 4;
		data_arr[5] = (uint8_t)( track & 0x20) >> 5;
		data_arr[6] = (uint8_t)( track & 0x40) >> 6;
		data_arr[7] = (uint8_t)( track & 0x80) >> 7; */
/*		for(i = 0;i<4;i++)
		{
			if(data_arr[i] == 0)
			{
				xunji_number_left++;
			}
		}
		for(i = 4;i<8;i++)
		{
			if(data_arr[i] == 0)
			{
				xunji_number_right++;
			}
		}
		
		//ת�����
		if(xunji_number_left >= 3)
		{
//			PWM_zhuanxiang = zhuanxiang_PID_value(yaw+90,yaw);
			left_turn_flag = 1;
			car_stop_flag = 0;
		}
		else if(xunji_number_right >= 3)
		{
//			PWM_zhuanxiang = zhuanxiang_PID_value(yaw-90,yaw);
			right_turn_flag = 1;
			car_stop_flag = 0;
		}
//		else
//		{		
			if(data_arr[0] == 0 || (data_arr[0] == 0 && data_arr[1] == 0 && data_arr[2] != 0))
			{
				speed = 0;
				car_stop_flag = 0;
			}
			else if(data_arr[1] == 0 || (data_arr[1] == 0 && data_arr[2] == 0))
			{
				speed = 250;
				car_stop_flag = 0;
			}
			else if(data_arr[2] == 0 || (data_arr[2] == 0 && data_arr[3] == 0))
			{
				speed = 300;
				car_stop_flag = 0;
			}
			else if(data_arr[7] == 0 || (data_arr[7] == 0 && data_arr[6] == 0 && data_arr[5] != 0 ))
			{
				speed = 800;
				car_stop_flag = 0;
			}
			else if(data_arr[6] == 0 || (data_arr[6] == 0 && data_arr[5] == 0))
			{
				speed = 550;
				car_stop_flag = 0;
			}
			else if(data_arr[5] == 0 || (data_arr[5] == 0 && data_arr[4] == 0))
			{
				speed = 500;
				car_stop_flag = 0;
			}
			
			else if(data_arr[3] == 0 || data_arr[4] == 0)
			{
				speed = 400;
				car_stop_flag = 0;
			}			
			else if(data_arr[0] == 0 && data_arr[1] == 0 && data_arr[2] == 0)
			{
				speed = 800;
				car_stop_flag = 0;
			}
			else if(data_arr[7] == 0 && data_arr[6] == 0 && data_arr[5] == 0 )
			{
				speed = 400;
				car_stop_flag = 0;
			}
						
			if((xunji_number_left + xunji_number_right) == 0 )//|| (xunji_number_left + xunji_number_right) >= 6)
			{
//				speed = 400;
				car_stop_flag = 1;
			}
//		}*/