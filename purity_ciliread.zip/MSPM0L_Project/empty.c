/*
 * Copyright (c) 2021, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <stdlib.h>
#include "board.h"
#include <stdio.h>
#include "bsp_mpu6050.h"
#include "inv_mpu.h"
#include "drv_oled.h"
#include "logic.h"
#include "Motor.h"
int16_t encodercount1;    
int16_t encodercount2;


int main(void)
{
	//�������ʼ��
	board_init();
	
	/*MPU6050_Init(); float pitch=0,roll=0,yaw=0;   //ŷ���� //��ȡŷ����
        if( mpu_dmp_get_data(&pitch,&roll,&yaw) == 0 )
        {
					display_6_8_number_f1(0,0,yaw); 
          display_6_8_number_f1(0,1,pitch);
					display_6_8_number_f1(0,2,roll);
					 
					printf("\r\npitch =%d\r\n", (int)pitch);
            printf("\r\nroll =%d\r\n", (int)roll);
            printf("\r\nyaw =%d\r\n", (int)yaw);
        }  */
	
    uint8_t ret = 1;
     oled_init();     
   

    //printf("start\r\n");

    //DMP��ʼ��
    while( mpu_dmp_init() )
    {
        //printf("dmp error\r\n");
        delay_ms(200);
    }
    //printf("Initialization Data Succeed \r\n");
		    NVIC_ClearPendingIRQ(TIMER_0_INST_INT_IRQN);
    //ʹ�ܶ�ʱ���ж�
    NVIC_EnableIRQ(TIMER_0_INST_INT_IRQN);
		
		NVIC_EnableIRQ(Encoder_INT_IRQN);	
    while(1) 
    {
				LCD_clear_L(0,0);
       
				display_6_8_number_f1(40,0,encodercount2); 
				display_6_8_number_f1(80,0,encodercount1); 
				extern uint16_t result;
				display_6_8_number_f1(0,0,result);
				
				LG(300);
				tackle_dat();
    }

}

void TIMER_0_INST_IRQHandler(void)
{
    //��������˶�ʱ���ж�
    switch( DL_TimerG_getPendingInterrupt(TIMER_0_INST) )
    {
        case DL_TIMER_IIDX_ZERO://�����0����ж�
            //��LED�Ƶ�״̬��ת
						Gray_read();	
            break;
        
        default://�����Ķ�ʱ���ж�
            break;
    }
}


/*//���ڵ��жϷ�����
void UART_0_INST_IRQHandler(void)
{
	//��������˴����ж�
	switch( DL_UART_getPendingInterrupt(UART_0_INST) )
	{
		case DL_UART_IIDX_RX://����ǽ����ж�
			//�ӷ��͹��������ݱ����ڱ�����
			//uart_data = DL_UART_Main_receiveData(UART_0_INST);
			//uart_data = DL_UART_Main_receiveData(UART_0_INST);
		
			
			//������������ٷ��ͳ�ȥ
			//uart0_send_char(uart_data);
			break;
		
		default://�����Ĵ����ж�
			break;
	}
}

void UART_1_INST_IRQHandler(void)
{	
	static uint8_t RxState1 = 0;		//�����ʾ��ǰ״̬��״̬�ľ�̬����
	static uint8_t pRxPacket1 = 0;	//�����ʾ��ǰ��������λ�õľ�̬����
	static uint8_t i = 0;
	
	//��������˴����ж�
	switch( DL_UART_getPendingInterrupt(UART_1_INST) )
	{
		case DL_UART_IIDX_RX://����ǽ����ж�
			//�ӷ��͹��������ݱ����ڱ�����
			RxData1 = DL_UART_Main_receiveData(UART_1_INST);
//			//������������ٷ��ͳ�ȥ
		
			static int i=0;
			Serial_RxPacket1[i++] = RxData1;
			if(Serial_RxPacket1[0] != 0x77) {i=0;}
			if( (i==2) && (Serial_RxPacket1[1] != 0x3A) ) {
				i=0;
			}else{
				reveive_data = 1;
			}

			if(reveive_data == 1)
			{
				if(Serial_RxPacket1[i-1] == 0x2E)
				{					
//					uart0_send_string("6");
//					i = 0;
					reveive_data = 2;
				}				
			}
			
			if(reveive_data == 2)
			{				
//				j = i - 3;
				for(j = 0; j < i-3; j++){		
					
					reveive_data_pack[j] = Serial_RxPacket1[j+2];
					
					if(reveive_data_pack[0] == 45)
					{
						fushu_flag = 1;
					}else{
						fushu_flag = 0;
					}
					
				}
				time = i-3;
				i = 0;
				reveive_data = 3;	
			}
			
						
			
			
			break;
		
		default://�����Ĵ����ж�
			break;
	}
}*/
void GROUP1_IRQHandler(void)
{
	switch(DL_Interrupt_getPendingGroup(DL_INTERRUPT_GROUP_1)) 
	{
		case Encoder_INT_IIDX:		
		if(DL_GPIO_getEnabledInterruptStatus(GPIOA, Encoder_B1_PIN))
		{
						if(DL_GPIO_readPins(GPIOA,Encoder_B1_PIN)==0)
						{
							if(DL_GPIO_readPins(GPIOA,Encoder_A1_PIN)==0)
								encodercount1--;
						}				
		}
				
		if(DL_GPIO_getEnabledInterruptStatus(GPIOA, Encoder_A1_PIN))
		{
					if(DL_GPIO_readPins(GPIOA,Encoder_A1_PIN)==0)
					{
						if(DL_GPIO_readPins(GPIOA,Encoder_B1_PIN)==0)
						encodercount1++;			
					}
		}
			
		if(DL_GPIO_getEnabledInterruptStatus(GPIOA, Encoder_B2_PIN))
		{
						if(DL_GPIO_readPins(GPIOA,Encoder_B2_PIN)==0)
						{
							if(DL_GPIO_readPins(GPIOA,Encoder_A2_PIN)==0)
								encodercount2++;
						}				
		}
	
		if(DL_GPIO_getEnabledInterruptStatus(GPIOA, Encoder_A2_PIN))
		{
					if(DL_GPIO_readPins(GPIOA,Encoder_A2_PIN)==0)
					{
						if(DL_GPIO_readPins(GPIOA,Encoder_B2_PIN)==0)
						encodercount2--;			
					}
		}
		break;
	}
		DL_GPIO_clearInterruptStatus(GPIOA, Encoder_B1_PIN);		
		DL_GPIO_clearInterruptStatus(GPIOA, Encoder_A1_PIN);
		DL_GPIO_clearInterruptStatus(GPIOA, Encoder_B2_PIN);		
		DL_GPIO_clearInterruptStatus(GPIOA, Encoder_A2_PIN);
}
